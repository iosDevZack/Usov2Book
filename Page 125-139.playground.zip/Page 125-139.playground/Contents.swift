import Foundation


//protocol MessageProtocol {
//    // текст сообщения
//    var text: String? { get set }
//
//    // прикрепленное изображение
//    var image: Data? { get set }
//
//    // прикрепленный аудиофайл
//    var audio: Data? { get set }
//
//    // прикрепленный видеофайл
//    var video: Data? { get set }
//
//    // дата отправки
//    var sendDate: Date { get set }
//
//    // отправитель
//    var senderID: UInt { get set }
//
//}
//
//struct Message: MessageProtocol {
//    var text: String?
//    var image: Data?
//    var audio: Data?
//    var video: Data?
//    var sendDate: Date
//    var senderID: UInt
//}
//
//protocol StatisticDelegate {
//    func handle(message: MessageProtocol)
//}
//
//
//protocol MessengerProtocol {
//
//    // массив всех сообщений
//    var messages: [MessageProtocol] { get set }
//
//    // делегат для ведения статистики
//    var statisticDelegate: StatisticDelegate? { get set }
//
//    // инициализатор
//    init()
//
//    // принять сообщение
//    mutating func receive(message: MessageProtocol)
//
//    // отправить сообщение
//    mutating func send(message: MessageProtocol)
//}
//
//
//struct StatisticManager: StatisticDelegate {
//    func handle(message: MessageProtocol) {
//        // ...
//        // обработка сообщения
//        // ...
//        print("обработка сообщения от User # \(message.senderID) завершена")
//
//    }
//}
//
//struct Messenger: MessengerProtocol {
//    var messages: [MessageProtocol]
//    var statisticDelegate: StatisticDelegate?
//    init() {
//        messages = []
//    }
//
//    mutating func receive(message: MessageProtocol) {
//        statisticDelegate?.handle(message: message)
//        messages.append(message)
//        // ...
//        // прием сообщения
//        // ...
//    }
//
//    mutating func send(message: MessageProtocol) {
//        statisticDelegate?.handle(message: message)
//        messages.append(message)
//        // ...
//        // отправка сообщения
//        // ...
//    }
//}
//
//var messenger = Messenger()
//messenger.statisticDelegate = StatisticManager()
//messenger.send(message: Message(text: "Привет", sendDate: Date(), senderID: 1))
//
//extension Messenger: StatisticDelegate {
//    func handle(message: MessageProtocol) {
//        //...
//        // обработка сообщения
//        // ...
//
//        print("обработка сообщения от User #\(message.senderID) завершена")
//    }
//}
//
//var messenger = Messenger()
//messenger.statisticDelegate = messenger.self
//
//messenger.send(message: Message(text:"Привет!", sendDate: Date(), senderID: 1)) messenger.messages.count // 1
//(messenger.statisticDelegate as! Messenger).messages.count // 0










//protocol MessageProtocol {
//    // текст сообщения
//    var text: String? { get set }
//
//    // прикрепленное изображение
//    var image: Data? { get set }
//
//    // прикрепленный аудиофайл
//    var audio: Data? { get set }
//
//    // прикрепленный видеофайл
//    var video: Data? { get set }
//
//    // дата отправки
//    var sendDate: Date { get set }
//
//    // отправитель
//    var senderID: UInt { get set }
//
//}
//
//struct Message: MessageProtocol {
//    var text: String?
//    var image: Data?
//    var audio: Data?
//    var video: Data?
//    var sendDate: Date
//    var senderID: UInt
//}
//
//protocol StatisticDelegate: AnyObject {
//    func handle(message: MessageProtocol)
//}
//
//protocol MessengerProtocol {
//    // массив всех сообщений
//    var messages: [MessageProtocol] { get set }
//    // делегат для ведения статистики
//    var statisticDelegate: StatisticDelegate? {get set}
//    // инициализатор
//    init()
//    //принять сообщение
//    mutating func recive(message: MessageProtocol)
//    //отправить сообщение
//    mutating func send(message: MessageProtocol)
//}
//
//class Messenger: MessengerProtocol {
//
//    var messages: [MessageProtocol]
//
//    weak var statisticDelegate: StatisticDelegate?
//
//    required init() {
//        messages = []
//    }
//
//    func recive(message: MessageProtocol) {
//        statisticDelegate?.handle(message: message)
//        messages.append(message)
//        //...
//        //прием сообщения
//        //
//    }
//
//    func send(message: MessageProtocol) {
//        statisticDelegate?.handle(message: message)
//        messages.append(message)
//        //...
//        //отправка сообщения
//        //...
//    }
//}
//
//extension Messenger: StatisticDelegate {
//    func handle(message: MessageProtocol) {
//        // ..
//        // обработка сообщения
//        // ...
//        print("Обработка сообщения от User #\(message.senderID) завершена")
//    }
//}
//
//var messenger = Messenger()
//messenger.statisticDelegate = messenger.self
//
//
//messenger.send(message: Message(text: "Привет!", sendDate: Date(), senderID: 1))
//messenger.messages.count // 1
//(messenger.statisticDelegate as! Messenger).messages.count // 1
//
//
//protocol MessengerDataSourceProtocol: class {
//    func getMessages() -> [MessageProtocol]
//}
//
//protocol MessengerProtocol {
//    // ...
//    // делегат для загрузки сообщения
//    var dataSource: MessengerDataSourceProtocol? { get set }
//    // ...
//}
//
//class Messenger: MessengerProtocol {
//    // ...
//    weak var dataSource: MessengerDataSourceProtocol? {
//     didSet {
//        if let source = dataSource {
//            messages = source.getMessages()
//        }
//    }
//}
//}
//
//extension Messenger: MessengerDataSourceProtocol {
//    func getMessages() -> [Message] {
//        return [Message(text: "Как дела?", sendDate: Date(), senderID: 2)]
//    }
//}
//
//var messenger = Messenger()
//messenger.dataSource = messenger.self
//messenger.messages.count //1



