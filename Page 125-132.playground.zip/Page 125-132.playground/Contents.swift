import Foundation


protocol MessageProtocol {
    // текст сообщения
    var text: String? { get set }
    
    // прикрепленное изображение
    var image: Data? { get set }
    
    // прикрепленный аудиофайл
    var audio: Data? { get set }
    
    // прикрепленный видеофайл
    var video: Data? { get set }
    
    // дата отправки
    var sendDate: Date { get set }
    
    // отправитель
    var senderID: UInt { get set }
    
}

struct Message: MessageProtocol {
    var text: String?
    var image: Data?
    var audio: Data?
    var video: Data?
    var sendDate: Date
    var senderID: UInt
}

protocol StatisticDelegate {
    func handle(message: MessageProtocol)
}


protocol MessengerProtocol {
    
    // массив всех сообщений
    var messages: [MessageProtocol] { get set }
    
    // делегат для ведения статистики
    var statisticDelegate: StatisticDelegate? { get set }
    
    // инициализатор
    init()
    
    // принять сообщение
    mutating func receive(message: MessageProtocol)
    
    // отправить сообщение
    mutating func send(message: MessageProtocol)
}


struct StatisticManager: StatisticDelegate {
    func handle(message: MessageProtocol) {
        // ...
        // обработка сообщения
        // ...
        print("обработка сообщения от User # \(message.senderID) завершена")
        
    }
}

struct Messenger: MessengerProtocol {
    var messages: [MessageProtocol]
    var statisticDelegate: StatisticDelegate?
    init() {
        messages = []
    }
    
    mutating func receive(message: MessageProtocol) {
        statisticDelegate?.handle(message: message)
        messages.append(message)
        // ...
        // прием сообщения
        // ...
    }
    
    mutating func send(message: MessageProtocol) {
        statisticDelegate?.handle(message: message)
        messages.append(message)
        // ...
        // отправка сообщения
        // ...
    }
    
}
